<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $items_html
 */
?>
<div class="wrap-forms">
	<?php echo $items_html ?>
</div>